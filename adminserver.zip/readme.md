# 安心账后台管理服务接口系统

此系统为aicoder.com内部使用的，权限管理后台数据接口服务器系统。

接口文档地址：https://malun666.github.io/radminserver/#/

## 起步

```sh
npm run start

# or u can use yarn

yarn start
```

## 使用

服务启动后，所有接口地址： `http://localhost:8888/XXXX/XXXX`

其他请参加[文档](https://malun666.github.io/radminserver/#/)。
